<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="hub.attach_image_module_info" />
<meta itemprop="path" content="Stable" />
</div>

# hub.attach_image_module_info

``` python
hub.attach_image_module_info(image_module_info)
```

Attaches an ImageModuleInfo message from within a module_fn.