<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="hub.ImageModuleInfo.InputSize" />
<meta itemprop="path" content="Stable" />
<meta itemprop="property" content="height"/>
<meta itemprop="property" content="width"/>
</div>

# hub.ImageModuleInfo.InputSize

## Class `InputSize`





## Class Members

<h3 id="height"><code>height</code></h3>

<h3 id="width"><code>width</code></h3>

