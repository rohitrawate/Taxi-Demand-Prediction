<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="hub.ImageModuleInfo" />
<meta itemprop="path" content="Stable" />
<meta itemprop="property" content="InputSize"/>
<meta itemprop="property" content="default_image_size"/>
</div>

# hub.ImageModuleInfo

## Class `ImageModuleInfo`





## Child Classes
[`class InputSize`](../hub/ImageModuleInfo/InputSize.md)

## Class Members

<h3 id="default_image_size"><code>default_image_size</code></h3>

